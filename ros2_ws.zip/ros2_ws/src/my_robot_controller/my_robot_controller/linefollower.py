#!/usr/bin/env python3


# Diese Node soll dazu dienen zwischen den beiden Linien zu fahren mit Hilfe von Ros2 und opencv.

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty


import numpy as np
import cv2
import cv_bridge

#Brücke zwischen Ros2 und opencv
bridge = cv_bridge.CvBridge()

#Jetzt folgen die Festlegungen, die auf der Strecke getestet werden müssen
#Mindestgröße eine Kontur, um erkannt zu werden
MIN_AREA = 200

#Mindestgröße einer Kontur, um als Linie der Strecke erkannt zu werden
MIN_LINE = 1300
#MIN_LINE = 2000

#Geschwindigkeit des Roboters
SPEED = 0.07

#Wert der Multipliziert wird, um Kurven zu fahren
CURVE = 0.0012

#Wie oft werden Messages pro Sekunde geschickt
TIMER_PERIOD = 0.5

#Nun folgen die Festlegungen der Farben
#Weiß:
low_bgr_white = np.array([150, 150, 150])
upper_bgr_white = np.array([255, 255, 255])

#Gelb:
#low_bgr_yellow = np.array([50, 50, 0])
#upper_bgr_yellow = np.array([255, 255, 150])

#Bildausschnitt in dem die Linie erkannt werden soll
HEIGHT = 1150
#HEIGHT = 950
#WIDTH = 750
WIDTH = 850

#globale Variablen
image_input = 0
error = 0
should_move = False
just_seen_line = False


def crop_size(height, width):

    #Wie das Image beschnitten wird, für den Bildausschnitt
    #(Oberer Rand, unterer Rand, linker Rand, rechter Rand)

    return (1*height//3, height, width//8, 3*width//4)


def image_callback(msg):

    # Funktion die aufgerufen wird, wenn ein neues Image kommt und updatet die globale variable "image_input"

    global image_input
    image_input = bridge.imgmsg_to_cv2(msg,desired_encoding='bgr8')

def get_contour_data(mask, out):

    #Funktion um die Konturen zu erkennen

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    mark = {}
    line = {}

    for contour in contours:

        M = cv2.moments(contour)

        if M['m00'] > MIN_AREA:

            if(M['m00'] > MIN_LINE):
                # Kontur gehört zur Linie

                line['x'] = crop_w_start + int(M["m10"]/M["m00"])
                line['y'] = int(M["m01"]/M["m00"])

                #Die Kontur in hellblau markieren
                cv2.drawContours(out, contour, -1, (255,255,0), 1)
                cv2.putText(out, str(M['m00']), (int(M["m10"]/M["m00"]), int(M["m01"]/M["m00"])),
                    cv2.FONT_HERSHEY_PLAIN, 2, (255,255,0), 2)
            
            else:
                # Kontur gehört generell zur Strecke
                if(not mark) or (mark['y'] > int(M["m10"]/M["m00"])):
                    # Wenn es mehrere Konturen gibt, wird die am nähesten zum Roboter genommen

                    mark['y'] = int(M["m01"]/M["m00"])
                    mark['x'] = crop_w_start + int(M["m10"]/M["m00"])

                    #Kontur wird in Pink angezeigt
                    cv2.drawContours(out, contour, -1, (255,0,255), 1)
                    cv2.putText(out, str(M['m00']), (int(M["m10"]/M["m00"]), int(M["m01"]/M["m00"])),
                        cv2.FONT_HERSHEY_PLAIN, 2, (255,0,255), 2)
    

    if mark and line:
        #Wenn beide Konturen existieren
        
        if mark['x'] > line['x']:
            mark_side = "right"
        else:
            mark_side = "left"
    else:
        mark_side = None

    return(line, mark_side)


def start_follower_callback(request, response):

    global should_move
    should_move = True

    return response

def stop_follower_callback(request, response):

    global should_move
    should_move = False

    return response


def timer_callback():
    # Funktion die während des Timers aufgerufen wird
    # Aufgrund des Image "image_input", die Fahrweise festlegen

    global error
    global image_input
    global crop_w_start
    global just_seen_line
    global should_move
    

    #Auf das erste Bild warten
    if type(image_input) != np.ndarray:
        return
    
    image = image_input.copy()


    crop_h_start, crop_h_stop, crop_w_start, crop_w_stop = crop_size(HEIGHT, WIDTH)

    # Den unteren Rand des Images bekommen
    crop = image[crop_h_start:crop_h_stop, crop_w_start:crop_w_stop]

    # Nun wird ein binärbild angefertigt, in dem die Werte, welche nicht 0 sind, die Linie anzeigen
    # außerdem werden hier die Farben gefiltert
    # erstmal nur für weiß
    mask_white = cv2.inRange(crop, low_bgr_white, upper_bgr_white)
    #mask_yellow = cv2.inRange(crop, low_bgr_yellow, upper_bgr_yellow)
    

    # Zentrum der größten Kontur und Seite bekommen und alles in das Outputbild einfügen
    output = image
    line_white, mark_side_white = get_contour_data(mask_white, output[crop_h_start:crop_h_stop, crop_w_start:crop_w_stop])
    #line_yellow, mark_side_yellow = get_contour_data(mask_yellow, output[crop_h_start:crop_h_stop, crop_w_start:crop_w_stop])

    message = Twist()

    if line_white:
        # Wenn es eine Linie gibt
        #just_seen_line = True
        x = line_white['x']

        # Unterschied zwischen Bildmitte und Mitte der Linie
        error = x - WIDTH//2
        just_seen_line = True
        message.linear.x = SPEED
        cv2.circle(output, (line_white['x'], crop_h_start + line_white['y']), 5, (0,255,0), 7)

    #if line_yellow:
        # Wenn es eine Linie gibt
        #just_seen_line = True
     #   cv2.circle(output, (line_yellow['x'], crop_h_start + line_yellow['y']), 5, (0,255,0), 7)
    
    else:
        # Es gibt keine Linie mehr im Bild
        if just_seen_line:
            just_seen_line = False

        message.linear.x = 0.0
    

    if error <= 0:
    
    	message.angular.z = float(error) * -0.003
    	
    elif error <= 80:

        message.angular.z = float(error) * CURVE

    elif error >= 125:

        message.angular.z = float(error) * -CURVE
    


    print("Error : {} | Angular Z: {}, ".format(error, message.angular.z))
    

    # Markierung des Imageauszuges
    cv2.rectangle(output, (crop_w_start, crop_h_start), (crop_w_stop, crop_h_stop), (0,0,255), 2)

    # Das Output Bild zeigen
    cv2.imshow("output", output)
    cv2.waitKey(5)

    if should_move:
        publisher.publish(message)
    else:
        empty_message = Twist()
        publisher.publish(empty_message)


def main():

    rclpy.init()
    global node

    node = Node('follower')

    global publisher
    #publisher = node.create_publisher(Twist, '/cmd_vel', rclpy.qos.qos_profile_system_default)
    publisher = node.create_publisher(Twist, '/cmd_vel', 10)

    #subscription = node.create_subscription(Image, 'image_raw', image_callback, rclpy.qos.qos_profile_sensor_data)
    subscription = node.create_subscription(Image, 'image_raw', image_callback, 10)


    timer = node.create_timer(TIMER_PERIOD, timer_callback)

    start_service = node.create_service(Empty, 'start_follower', start_follower_callback)
    stop_service = node.create_service(Empty, 'stop_follower', stop_follower_callback)

    rclpy.spin(node)

try:
    main()
except (KeyboardInterrupt, rclpy.exceptions.ROSInterruptException):
    node.destroy_node()
    rclpy.shutdown()
    exit()
